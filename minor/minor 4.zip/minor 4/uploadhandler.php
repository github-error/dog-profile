<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$con = new mysqli("localhost", "root", "", "animowrld");
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Get user ID
$stmt = $con->prepare("SELECT user_id FROM accounts WHERE username = ?");
$stmt->bind_param("s", $_SESSION['username']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$user_id = $user['user_id'] ?? 0;

$folderPath = 'Images/';
if (!is_dir($folderPath)) {
    mkdir($folderPath, 0777, true);
}

if (isset($_POST['submit']) && isset($_FILES['fileToUpload'])) {
    $file = $_FILES['fileToUpload'];
    $originalName = basename($file['name']);
    $ext = pathinfo($originalName, PATHINFO_EXTENSION);
    $uniqueName = uniqid("img_", true) . '.' . $ext;
    $uploadPath = $folderPath . $uniqueName;

    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        $stmt = $con->prepare("INSERT INTO post (user_id, image, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("is", $user_id, $uniqueName);
        $stmt->execute();
        header("Location: sharepost.php?success=1");
        exit();
    } else {
        echo "❌ File upload failed.";
    }
} else {
    echo "❌ No file selected.";
}
?>
